// SPDX-License-Identifier: Apache-2.0
#pragma once
// Experimental FP32 standalone AllGather/ReduceScatter. Reuse the tested
// MSCCL++ primitives and physical Gray-code ring from the AllReduce experiment.
#include "pro6000_allreduce.cuh"

namespace uccl_lite {
struct AgRsLayout {
  size_t input, output, partial, receive, packets;
};
struct AgRsChannels {
  Chan peers[kRanks];
  PortChan first, partial, gather, incoming;
  Chan acknowledge, drained;
};

// Every element exchanges with every rank before its next invocation can
// finish. Two packet generations therefore prevent overwrite of unread data.
// Packet positions encode SOURCE rank; RS input positions encode DESTINATION
// rank. Output always uses public rank order, independent of ring order.
template <bool Gather>
__global__ void agRsLL(AgRsChannels const* channels, char* base, int rank,
                       size_t shard, AgRsLayout layout, uint32_t* epochs,
                       size_t packetSlot) {
  __shared__ uint32_t flag;
  if (threadIdx.x == 0) flag = ++epochs[blockIdx.x];
  __syncthreads();
  layout.packets += (flag & 1) * packetSlot;
  auto const& ch = channels[0];
  float const* input = reinterpret_cast<float*>(base + layout.input);
  float* output = reinterpret_cast<float*>(base + layout.output);
  auto rx = reinterpret_cast<Pkt*>(base + layout.packets);
  size_t pairs = shard / 2;
  for (size_t j = blockIdx.x * blockDim.x + threadIdx.x; j < pairs;
       j += size_t(gridDim.x) * blockDim.x) {
    float2 local =
        reinterpret_cast<float2 const*>(input)[(Gather ? 0 : rank * pairs) + j];
    for (int delta = 1; delta < kRanks; ++delta) {
      int peer = (rank + delta) % kRanks;
      auto tx = reinterpret_cast<Pkt*>(static_cast<char*>(ch.peers[peer].dst_) +
                                       layout.packets);
      float2 value =
          Gather ? local
                 : reinterpret_cast<float2 const*>(input)[peer * pairs + j];
      tx[rank * pairs + j].write(f2u(value), flag);
    }
    if (Gather) reinterpret_cast<float2*>(output)[rank * pairs + j] = local;
    for (int peer = 0; peer < kRanks; ++peer) {
      if (peer == rank) continue;
      float2 value = u2f(rx[peer * pairs + j].read(flag));
      if (Gather)
        reinterpret_cast<float2*>(output)[peer * pairs + j] = value;
      else {
        local.x += value.x;
        local.y += value.y;
      }
    }
    if (!Gather) reinterpret_cast<float2*>(output)[j] = local;
  }
}

// Direct SM writes avoid packet expansion in the medium-size range. Each lane
// owns a disjoint interval and its own peer semaphores. The second handshake
// protects RS readers and the next invocation's input/output reuse.
template <bool Gather>
__global__ void agRsPut(AgRsChannels const* channels, char* base, int rank,
                        size_t shard, size_t tile, AgRsLayout layout,
                        mscclpp::DeviceSyncer* syncers, int workers) {
  int lane = blockIdx.x / workers, lanes = gridDim.x / workers;
  int tid = (blockIdx.x % workers) * blockDim.x + threadIdx.x;
  int nth = blockDim.x * workers;
  auto ch = channels[lane];
  float const* input = reinterpret_cast<float*>(base + layout.input);
  float* output = reinterpret_cast<float*>(base + layout.output);
  float const* receive = reinterpret_cast<float*>(base + layout.receive);
  for (size_t offset = lane * tile; offset < shard; offset += lanes * tile) {
    size_t count = min(tile, shard - offset);
    for (int delta = 1; delta < kRanks; ++delta) {
      int p = (rank + delta) % kRanks;
      size_t src = layout.input + (Gather ? offset : p * shard + offset) * 4;
      size_t dst = (Gather ? layout.output : layout.receive) +
                   (rank * shard + offset) * 4;
      ch.peers[p].template put<16, true>(dst, src, count * 4, tid, nth);
    }
    __threadfence_system();
    syncers[lane].sync(workers);
    if (tid == 0) {
      for (int p = 0; p < kRanks; ++p)
        if (p != rank) ch.peers[p].signal();
      for (int p = 0; p < kRanks; ++p)
        if (p != rank) ch.peers[p].wait();
    }
    syncers[lane].sync(workers);
    if (Gather)
      copyOut(output + rank * shard + offset, input + offset, count, tid, nth);
    else {
      copyOut(output + offset, input + rank * shard + offset, count, tid, nth);
      for (int p = 0; p < kRanks; ++p)
        if (p != rank)
          addInto(output + offset, receive + p * shard + offset, count, tid,
                  nth);
    }
    __threadfence_system();
    syncers[lane].sync(workers);
    if (tid == 0) {
      for (int p = 0; p < kRanks; ++p)
        if (p != rank) ch.peers[p].signal();
      for (int p = 0; p < kRanks; ++p)
        if (p != rank) ch.peers[p].wait();
    }
    syncers[lane].sync(workers);
  }
}

// Each lane owns a contiguous interval WITHIN each rank's shard. This retains
// public rank-contiguous output, unlike the tiled AllReduce's internal shard
// assignment. Partial sums have distinct immutable positions until completion.
template <bool Gather>
__global__ void agRsRingCE(AgRsChannels const* channels, char* base, int rank,
                           size_t shard, size_t tile, AgRsLayout layout,
                           mscclpp::DeviceSyncer* syncers, int workers) {
  int lane = blockIdx.x / workers, lanes = gridDim.x / workers;
  int tid = (blockIdx.x % workers) * blockDim.x + threadIdx.x;
  int nth = blockDim.x * workers;
  auto ch = channels[lane];
  int position = ringPosition(rank);
  float const* input = reinterpret_cast<float*>(base + layout.input);
  float* output = reinterpret_cast<float*>(base + layout.output);
  float* partial = reinterpret_cast<float*>(base + layout.partial);
  float const* receive = reinterpret_cast<float*>(base + layout.receive);
  for (size_t offset = lane * tile; offset < shard; offset += lanes * tile) {
    size_t count = min(tile, shard - offset);
    if (Gather) {
      copyOut(output + rank * shard + offset, input + offset, count, tid, nth);
      __threadfence_system();
      syncers[lane].sync(workers);
      if (tid == 0) {
        for (int step = 0; step < kRanks - 1; ++step) {
          int owner = ringRank((position - step + kRanks) % kRanks);
          size_t bytes = (owner * shard + offset) * sizeof(float);
          ch.gather.putWithSignal(bytes, bytes, count * sizeof(float));
          ch.incoming.wait();
        }
      }
    } else {
      for (int step = 0; step < kRanks - 1; ++step) {
        int sendOwner = ringRank((position - 1 - step + kRanks) % kRanks);
        int recvOwner = ringRank((position - 2 - step + kRanks) % kRanks);
        __threadfence_system();
        syncers[lane].sync(workers);
        if (tid == 0) {
          auto port = step == 0 ? ch.first : ch.partial;
          size_t bytes = (sendOwner * shard + offset) * sizeof(float);
          port.putWithSignal(bytes, bytes, count * sizeof(float));
          ch.incoming.wait();
        }
        syncers[lane].sync(workers);
        size_t keep = recvOwner * shard + offset;
        float* dst = step == kRanks - 2 ? output + offset : partial + keep;
        addOut(dst, input + keep, receive + keep, count, tid, nth);
      }
      // The final reduction must finish before the receive region is released.
      __threadfence_system();
      syncers[lane].sync(workers);
    }
    if (tid == 0) {
      ch.acknowledge.signal();
      ch.drained.wait();
    }
    syncers[lane].sync(workers);
  }
}
}  // namespace uccl_lite
