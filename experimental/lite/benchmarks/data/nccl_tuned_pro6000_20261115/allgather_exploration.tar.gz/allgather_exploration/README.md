# NCCL AllGather recheck on aws-pro6000, 2026-11-15

The [copy-engine follow-up](ce_probe/README.md) enables registered symmetric
buffers plus `NCCL_CTA_POLICY=2`, verifies CE selection and profiles memcpy
activity. At 1 GiB it measures 35.85 GB/s versus a fresh 29.13 GB/s default
control; these later measurements are separate from the original sweeps below.

Default NCCL selected **PCIe P2P**, with all eight logged directed channel
edges using `P2P/direct pointer` (four channels in each direction). No SHM
data-channel edges were logged. See [full INFO log](transport_debug.log)
and [extracted edges](transport_edges.txt). The log also says `Using network
Socket`; that identifies the available network backend, while the actual
local channel lines establish P2P transport. AWS OFI initialization warnings
are retained in the raw output. All processes completed successfully.

Hardware: two NVIDIA RTX PRO 6000 Blackwell Server Edition GPUs, PCIe Gen5
x16, same PCIe switch (`PIX`), Xeon Platinum 8559C, one NUMA node. Driver
595.91.07, CUDA runtime 13.0, NCCL 2.29.7+cuda13.2. See
[environment and hashes](environment.txt) and [PCIe link state](pcie_link.txt).

The baseline reuses the existing `uccl_lite_collectives` binary from
`/home/xinze/dev/uccl-lite-blackwell-20261113/build/`, with `--fallback nccl
--backend off`, BF16, out of place, GPUs 0 and 1, main CPU 23. It calls
`ncclAllGather` through the existing single-process harness. CPU-router
initialization remained disabled at every size. No source or binary was
modified or rebuilt. These are fresh measurements of that recorded binary,
not validation of the current workspace source.

Sizes are powers of two from **1 MiB to 1 GiB of complete output per GPU**,
matching the earlier reports. Each GPU contributes half this amount.
Bus bandwidth is `output_bytes * (nranks - 1) / nranks / seconds / 1e9`;
for two GPUs this is `output_bytes / (2 * seconds) / 1e9`, in decimal GB/s.

Three independent timing sweeps each use five warmups per size followed by
five rounds of ten individually checked calls. Timing is the slowest-rank
CUDA-event interval, including eager submission/progress gaps; filling,
verification, allocation, communicator initialization, and warmup are outside
the interval. This is not graph replay or batched nccl-tests throughput.
Each sweep reports the median of its five round medians; the table uses the
median of the three sweep medians. Ranges are across sweep medians, not
confidence intervals. No best-variant selection or transport tuning is used.

The separate INFO transport sweep covers all eleven sizes with one warmup
and three checked calls per size. Timing sweeps use `NCCL_DEBUG=WARN`.
There were no inherited NCCL variables and no `/etc/nccl.conf` or
`~/.nccl.conf`. No P2P, SHM, algorithm, or protocol override was applied.
SHM/P2P here denotes transport; this trace does not establish per-size
Simple/LL/LL128 protocol selection.

All four sweeps passed correctness on both ranks after every invocation,
including **1,650 timed performance calls** plus transport checks and warmups.

| Complete output/GPU (MiB) | Bus bandwidth (GB/s) | Across-run range (GB/s) |
| ---: | ---: | ---: |
| 1 | 12.91 | 12.75–12.91 |
| 2 | 18.07 | 18.07–18.07 |
| 4 | 22.59 | 22.59–22.84 |
| 8 | 24.71 | 24.58–24.71 |
| 16 | 25.54 | 25.54–25.54 |
| 32 | 26.06 | 26.06–26.06 |
| 64 | 26.49 | 26.45–26.51 |
| 128 | 26.76 | 26.76–26.79 |
| 256 | 27.25 | 27.24–27.28 |
| 512 | 27.94 | 27.85–28.22 |
| 1024 | 28.94 | 28.80–29.40 |

[Summary CSV](summary.csv) preserves latency and unrounded bandwidth values.
[Commands and timestamps](runs.json), [runner](run.py), and
[summary script](summarize.py) make the run reproducible. Raw CSV files include
NCCL startup messages before the CSV header; the summary script handles them.
Remote output is under
`/home/xinze/dev/uccl-lite-blackwell-20261113/build/nccl_allgather_20261115/`.

## Follow-up protocol and channel diagnostics

Fresh diagnostics on the same host and unchanged binary used the shared
`/home/xinze/dev/uccl-eat-pro6000/eval.lock`. The process list was empty before
profiling. These controls are separate from the three primary sweeps above.

`selection_debug.log` records `NCCL_DEBUG=INFO` with subsystems
`INIT,TUNING,COLL`: **every size uses RING/SIMPLE on channels 0–3**.
NCCL's tuning log prints contribution bytes, half the full-output sizes in
this report. The sweep used one warmup and three repeats of one call.

A separate one-warmup/three-call Nsight Systems diagnostic at 1 GiB full
output produced `diagnostic_1g_cuda_gpu_kern_sum.csv` and
`diagnostic_1g_cuda_api_sum.csv`. The raw nsys report and SQLite database remain
in the remote build output directory. Its kernel is named
`ncclDevKernel_AllGather_RING_LL`, but **this does not identify the executed
protocol**: NCCL v2.29.7-1 `src/device/generate.py::best_kernel` maps AllGather
functions to that kernel name. The tuning log establishes SIMPLE. The first
interpretation of that kernel name as LL was incorrect.

Independent sequential default and `NCCL_PROTO=Simple` sweeps used the same
1 MiB–1 GiB command as the primary measurements, with five warmups and five
rounds of ten calls. Then two 1-GiB-only controls set both
`NCCL_MIN_NCHANNELS` and `NCCL_MAX_NCHANNELS` to 16 or 32, with the same
warmup/repetition counts. Channel controls used `NCCL_DEBUG=INFO` with
`INIT,TUNING` and separate debug files. Logs verify SIMPLE and the requested
channel ranges. All checks passed. These are single-sweep diagnostics, not
independent performance confirmation or a best-variant curve.

| 1 GiB full output/GPU | Median latency (us) | Bus bandwidth (GB/s) |
| --- | ---: | ---: |
| Default, 4 channels | 18641.536 | 28.80 |
| Forced Simple, 4 channels | 18688.160 | 28.73 |
| 16 channels | 17289.887 | 31.05 |
| 32 channels | 17311.408 | 31.01 |

Raw `protocol_*` and `channels_*` files preserve all timings and samples.
The controls rule out an LL-selection explanation and show a modest channel
count benefit. They do not isolate PCIe transaction efficiency, GPU instruction
throughput, or synchronization stalls. NCCL's Simple ring processes chunks
through SM copy/send/receive primitives with per-slice coordination; the
retained UCCL large-AG code uses bulk local/peer CUDA copies. This is a
code-level explanation for the different data paths, not an attribution of
the measured gap to a single hardware bottleneck.
