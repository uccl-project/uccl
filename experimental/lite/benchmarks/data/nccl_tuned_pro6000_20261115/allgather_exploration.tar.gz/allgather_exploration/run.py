#!/usr/bin/env python3
"""Repeat the existing BF16 NCCL baseline with transport evidence."""
import hashlib
import json
import os
from pathlib import Path
import shlex
import subprocess
from datetime import datetime, timezone

root = Path('/home/xinze/dev/uccl-lite-blackwell-20261113')
out = root / 'build/nccl_allgather_20261115'
out.mkdir(exist_ok=True)
binary = root / 'build/uccl_lite_collectives'
env = {k: v for k, v in os.environ.items() if not k.startswith('NCCL_')}
env['LD_LIBRARY_PATH'] = '/opt/pytorch/cuda/lib:' + env.get('LD_LIBRARY_PATH', '')
env['CUDA_VISIBLE_DEVICES'] = '0,1'
records = []
with (out / 'environment.txt').open('w') as f:
    for cmd in [['date', '-u'], ['hostname'], ['nvidia-smi'],
                ['nvidia-smi', 'topo', '-m'], ['lscpu'], ['ldd', str(binary)]]:
        f.write(shlex.join(cmd) + '\n')
        f.flush()
        subprocess.run(cmd, stdout=f, stderr=subprocess.STDOUT, check=True)
    f.write('inherited NCCL variables: ' + json.dumps({k: v for k, v in os.environ.items() if k.startswith('NCCL_')}) + '\n')
    for path in [Path('/etc/nccl.conf'), Path.home() / '.nccl.conf']:
        f.write(str(path) + ': ' + (path.read_text() if path.exists() else 'absent') + '\n')
    for path in [binary, root / 'benchmarks/cpu_router/collectives_bench.cu',
                 Path('/home/xinze/dev/uccl-lite-test-20261113/build/testbed/deps/nccl/lib/libnccl.so.2')]:
        f.write(hashlib.sha256(path.read_bytes()).hexdigest() + '  ' + str(path) + '\n')

for name in ['transport', 'run1', 'run2', 'run3']:
    trace = name == 'transport'
    runenv = dict(env, NCCL_DEBUG='INFO' if trace else 'WARN')
    if trace:
        runenv.update(NCCL_DEBUG_SUBSYS='INIT,GRAPH,P2P,SHM,NET,ENV',
                      NCCL_DEBUG_FILE=str(out / 'transport_debug.log'))
    cmd = [str(binary), '--gpus', '2', '--fallback', 'nccl', '--backend', 'off',
           '--main-cpu', '23', '--op', 'allgather', '--begin', '1048576',
           '--end', '1073741824', '--warmup', '1' if trace else '5',
           '--iterations', '1' if trace else '10', '--repeats', '3' if trace else '5',
           '--samples', str(out / (name + '_samples.csv'))]
    started = datetime.now(timezone.utc).isoformat()
    print(name + ': starting', flush=True)
    with (out / (name + '.csv')).open('x') as stdout, (out / (name + '.log')).open('x') as stderr:
        result = subprocess.run(cmd, env=runenv, stdout=stdout, stderr=stderr, timeout=600)
    records.append(dict(name=name, command=shlex.join(cmd), started_utc=started,
                        finished_utc=datetime.now(timezone.utc).isoformat(),
                        environment={k: v for k, v in runenv.items() if k.startswith(('NCCL_', 'CUDA_', 'LD_LIBRARY_PATH'))},
                        returncode=result.returncode))
    (out / 'runs.json').write_text(json.dumps(records, indent=2) + '\n')
    assert result.returncode == 0, name
    assert '# correctness: PASS (every invocation, all ranks)' in (out / (name + '.csv')).read_text(), name
    if trace:
        edges = [line for line in (out / 'transport_debug.log').read_text().splitlines()
                 if 'Channel ' in line and ' -> ' in line and ' via ' in line]
        assert edges, 'No NCCL transport edges found'
        (out / 'transport_edges.txt').write_text('\n'.join(edges) + '\n')
        print('\n'.join(edges[:8]), flush=True)
    print(name + ': correctness PASS', flush=True)
