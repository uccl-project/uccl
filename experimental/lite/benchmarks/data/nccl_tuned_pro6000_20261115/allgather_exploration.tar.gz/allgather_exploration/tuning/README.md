# NCCL AllGather knob tuning on aws-pro6000

This 2026-11-15 experiment tunes process-local NCCL settings on the same
two RTX PRO 6000 Blackwell Server Edition GPUs as the parent report. No
NCCL library, application source, GPU clock setting, or system-wide environment
was modified. Existing original and registered-buffer probe binaries were reused.

## Scope and protocol

Hardware: two RTX PRO 6000 Blackwell Server Edition GPUs, PCIe Gen5 x16,
same PCIe switch (`PIX`), Xeon Platinum 8559C, one NUMA node. Driver 595.91.07,
CUDA runtime 13.0, NCCL 2.29.7+cuda13.2. All tests use BF16, out-of-place
AllGather in one process on GPUs 0 and 1, with the main thread on CPU 23.
Sizes are every power of two from **1 MiB to 1 GiB complete output per GPU**;
each rank's contribution is half that size. Bus bandwidth in decimal GB/s
is `output_bytes / 2 / seconds / 1e9`.

The initial screen has 36 candidate configurations plus two extra default
controls. A second screen refines the promising memcpy transport with 21
candidate/control configurations. The total is 59 short screening processes,
each with three warmups and three rounds of three timed calls per size.
Screen order is deterministically shuffled. All failures and negative results
are retained; all 59 screens passed full-output correctness.

Before confirmation, fixed configurations are selected by geometric-mean
speedup across 1 MiB–1 GiB and 64 MiB–1 GiB; the best plain-buffer 1-GiB
candidate is also retained. Default, registered-default, zero-CTA CE and
one-knob memcpy controls are kept for comparison. These criteria produce
eight configurations in [selected.json](selected.json). No configuration
is selected using confirmation timings.

Each finalist runs in three independent processes, rotating/reversing
configuration order. Each size gets five warmups and five rounds of ten
timed calls. Timing is the maximum-rank CUDA-event interval; eager submission
gaps are included. Allocation, registration, communicator setup, warmups,
input fill and full-output verification are outside timing. The median of
the five round medians forms a run result; the reported result is the median
of three run results. Across-run ranges are descriptive, not confidence
intervals. Every reported configuration stays fixed across sizes; no curve
selects the fastest variant at each size.

The shared `/home/xinze/dev/uccl-eat-pro6000/eval.lock` is held during each
stage, and the runner checks GPU occupancy before each process. It clears
inherited `NCCL_*` and `UCCL_LITE_*` variables and records every override.
Performance runs use WARN logging. Separate TRACE runs inspect actual
transport, algorithm, protocol, channel count and chunk geometry; trace
timings are excluded from results.

## Settings examined

- `NCCL_P2P_PCI_CHUNKSIZE`: 256/512 KiB and 1/2/4 MiB requests, both alone
  and with sufficient `NCCL_BUFFSIZE` to avoid the internal cap.
- `NCCL_BUFFSIZE`: 1, 2, 4 (default), 8, 16 and 32 MiB.
- `NCCL_MIN_NCHANNELS` and `NCCL_MAX_NCHANNELS`: fixed 2/4/8/16/32 channels.
- `NCCL_NTHREADS`: 128/256 versus default.
- `NCCL_P2P_READ_ENABLE=1`.
- `NCCL_P2P_USE_CUDA_MEMCPY=1`, with buffer/channel/chunk/thread combinations.
- The existing registered-buffer probe with default policy, buffer/thread
  tuning, memcpy transport, or `NCCL_CTA_POLICY=2`.

The initial controls reproduce the previous finding that the zero-CTA CE
path requires NCCL-managed symmetric registered buffers. The memcpy
**transport** is a separate path and works with the original cudaMalloc
benchmark. It retains the Ring/Simple collective kernel and CPU proxy
progress, while offloading peer data copies; it is not a zero-SM collective.
Its shared-host structures carry synchronization/control state, which should
not be confused with selecting the SHM data transport.

For this NCCL version, increasing `NCCL_P2P_PCI_CHUNKSIZE` alone does not
change the Ring AllGather chunk calculation. That calculation uses
`NCCL_BUFFSIZE / NCCL_STEPS` and the collective's chunk-step factor.
NCCL also caps the requested P2P chunk to `NCCL_BUFFSIZE / NCCL_STEPS`, so
a 2-MiB request with the default buffer is reduced to 512 KiB.
See [buffer initialization](https://github.com/NVIDIA/nccl/blob/v2.29.7-1/src/init.cc#L753),
[collective chunk calculation](https://github.com/NVIDIA/nccl/blob/v2.29.7-1/src/enqueue.cc#L2091),
and [P2P memcpy transport](https://github.com/NVIDIA/nccl/blob/v2.29.7-1/src/transport/p2p.cc#L798).

## Artifacts and reproduction

- [run.py](run.py): screening, refinement, confirmation and trace runner.
- [candidates.json](candidates.json), [refine_candidates.json](refine_candidates.json): all candidates.
- [screen_scores.csv](screen_scores.csv): screening rankings and negative results.
- [analyze_screen.py](analyze_screen.py): freeze finalists from screening data.
- [selected.json](selected.json): fixed independent confirmation configurations.
- [analyze_confirm.py](analyze_confirm.py): reconstruct all confirmation medians
  from raw samples, validate counts/correctness, and calculate fixed-configuration results.
- `*_runs.json`: exact commands, environments, timestamps, exit codes and correctness status.
- `*_hashes.json`: original/probe executable hashes for each stage.
- Raw `screen_*`, `refine_*`, `confirm_*` and `trace_*` files retain all results.

The runner resides remotely at
`/home/xinze/dev/uccl-lite-blackwell-20261113/build/run_nccl_tuning.py`.
Remote outputs are under `build/nccl_allgather_20261115/tuning/`. Output files
are created exclusively, so use a fresh output directory for any rerun.
The two executable paths and their preparation are documented in the parent
[copy-engine report](../ce_probe/README.md). No compilation was needed for
this knob-only study. It does not validate current workspace source changes,
other GPU topologies, graphs, concurrent compute or application performance.
