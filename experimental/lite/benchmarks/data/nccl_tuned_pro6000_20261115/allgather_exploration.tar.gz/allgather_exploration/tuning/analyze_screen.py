#!/usr/bin/env python3
"""Select fixed configurations from screening, before confirmation timings."""
import csv
import json
import math
from pathlib import Path
from statistics import median

root = Path(__file__).resolve().parent
def rows(name):
    text = (root / (name + '.csv')).read_text()
    assert '# correctness: PASS (every invocation, all ranks)' in text
    data = list(csv.DictReader(line for line in text.splitlines()
                              if line.startswith(('collective,', 'all_gather,'))))
    assert len(data) == 11
    return {int(r['bytes']): float(r['median_us']) for r in data}

controls = [rows(n) for n in ['screen_default_before', 'screen_default', 'screen_default_after']]
baseline = {size: median(c[size] for c in controls) for size in controls[0]}
configs = json.loads((root / 'candidates.json').read_text())
runs = {r['name']: r for r in json.loads((root / 'screen_runs.json').read_text())}
prefix = {c['name']: 'screen_' for c in configs}
if (root / 'refine_candidates.json').exists():
    refined = json.loads((root / 'refine_candidates.json').read_text())
    configs += refined
    prefix.update({c['name']: 'refine_' for c in refined})
    runs.update({r['name']: r for r in json.loads((root / 'refine_runs.json').read_text())})
scores = []
for c in configs:
    name = prefix[c['name']] + c['name']
    if not runs[name]['correctness_pass']:
        continue
    times = rows(name)
    gm = lambda sizes: math.exp(sum(math.log(baseline[s] / times[s]) for s in sizes) / len(sizes))
    scores.append(dict(name=c['name'], memory=c['memory'],
                       full_speedup=gm(list(times)),
                       large_speedup=gm([s for s in times if s >= 64 << 20]),
                       gbps_1g=(1 << 29) / times[1 << 30] / 1000,
                       settings=json.dumps(c['settings'], sort_keys=True)))
with (root / 'screen_scores.csv').open('w') as f:
    writer = csv.DictWriter(f, fieldnames=list(scores[0]))
    writer.writeheader()
    writer.writerows(sorted(scores, key=lambda r: r['full_speedup'], reverse=True))

selected_names = ['default', 'registered_default', 'ce']
for memory in ['plain', 'registered']:
    eligible = [s for s in scores if s['memory'] == memory
                and not s['name'].startswith(('ce', 'refine_'))]
    metrics = ['full_speedup', 'large_speedup'] + (['gbps_1g'] if memory == 'plain' else [])
    for metric in metrics:
        winner = max(eligible, key=lambda r: r[metric])['name']
        if winner not in selected_names:
            selected_names.append(winner)
selected = [next(c for c in configs if c['name'] == name) for name in selected_names]
# Keep the one-knob memcpy baseline in confirmation to isolate the extra tuning.
if 'transport_memcpy' not in selected_names:
    selected_names.append('transport_memcpy')
    selected.append(next(c for c in configs if c['name'] == 'transport_memcpy'))
(root / 'selected.json').write_text(json.dumps(selected, indent=2) + '\n')
traced_names = list(dict.fromkeys(selected_names + ['p2p_512k', 'p2p_2048k', 'p2p_2m_buffer_16m', 'buffer_16m']))
(root / 'trace_selected.json').write_text(json.dumps(
    [next(c for c in configs if c['name'] == name) for name in traced_names], indent=2) + '\n')
for score in sorted(scores, key=lambda s: s['full_speedup'], reverse=True):
    print(f'{score["name"]:38} full={score["full_speedup"]:.3f} large={score["large_speedup"]:.3f} 1GiB={score["gbps_1g"]:.2f} GB/s')
print('Frozen for confirmation:', ', '.join(selected_names))
