#!/usr/bin/env python3
"""Reconstruct independent confirmation results without selecting per-size winners."""
import csv
import json
import math
from pathlib import Path
from statistics import median

root = Path(__file__).resolve().parent
configs = json.loads((root / 'selected.json').read_text())
names = [c['name'] for c in configs]
runs = json.loads((root / 'confirm_runs.json').read_text())
assert len(runs) == len(configs) * 3
assert all(r['correctness_pass'] and r['returncode'] == 0 for r in runs)
timings = {name: {} for name in names}
for name in names:
    for repeat in range(1, 4):
        stem = f'confirm_{name}_run{repeat}'
        raw = (root / (stem + '.csv')).read_text()
        assert '# correctness: PASS (every invocation, all ranks)' in raw
        rows = list(csv.DictReader(line for line in raw.splitlines()
                                   if line.startswith(('collective,', 'all_gather,'))))
        assert len(rows) == 11
        with (root / (stem + '_samples.csv')).open() as f:
            samples = list(csv.DictReader(f))
        assert len(samples) == 550
        for row in rows:
            assert row['in_place'] == '0' and row['dispatcher_router_initialized'] == '0'
            size = int(row['bytes'])
            group = [s for s in samples if int(s['bytes']) == size]
            assert len({(s['repeat'], s['iteration']) for s in group}) == 50
            medians = [median(float(s['slowest_rank_us']) for s in group if int(s['repeat']) == r)
                       for r in range(5)]
            value = median(medians)
            assert abs(value - float(row['median_us'])) < 0.001
            timings[name].setdefault(size, []).append(value)

results = []
for name in names:
    for size in sorted(timings[name]):
        values = timings[name][size]
        us = median(values)
        bw = lambda t: size / 2 / t / 1000
        results.append(dict(configuration=name, output_bytes_per_gpu=size,
                            median_us=us, bus_GB_s=bw(us),
                            min_bus_GB_s=bw(max(values)), max_bus_GB_s=bw(min(values)),
                            speedup_vs_default=median(timings['default'][size]) / us,
                            run1_us=values[0], run2_us=values[1], run3_us=values[2]))
with (root / 'confirmation.csv').open('w') as f:
    w = csv.DictWriter(f, fieldnames=list(results[0]))
    w.writeheader()
    w.writerows(results)
summary = {}
for name in names:
    rows = [r for r in results if r['configuration'] == name]
    gm = lambda group: math.exp(sum(math.log(r['speedup_vs_default']) for r in group) / len(group))
    summary[name] = dict(full_speedup=gm(rows), large_speedup=gm([r for r in rows if r['output_bytes_per_gpu'] >= 64 << 20]),
                         gbps_1g=rows[-1]['bus_GB_s'], wins=sum(r['speedup_vs_default'] > 1 for r in rows))
(root / 'confirmation_summary.json').write_text(json.dumps(summary, indent=2) + '\n')
for name, values in summary.items():
    print(name, json.dumps(values))
table_names = ['default', 'ce', 'transport_memcpy', 'memcpy_buffer_8m_channels_8', 'memcpy_buffer_16m_channels_8']
print('| Output MiB | Default | Zero-CTA CE | Memcpy only | Memcpy 8MiB/8ch | Memcpy 16MiB/8ch |')
for size in sorted(timings['default']):
    print('| ' + str(size // (1 << 20)) + ' | ' + ' | '.join(
        f'{size / 2 / median(timings[name][size]) / 1000:.2f}' for name in table_names) + ' |')
