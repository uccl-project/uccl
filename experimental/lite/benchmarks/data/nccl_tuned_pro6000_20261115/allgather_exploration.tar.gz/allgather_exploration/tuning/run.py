#!/usr/bin/env python3
"""Screen and independently confirm process-local NCCL settings."""
import argparse
import csv
from datetime import datetime, timezone
import fcntl
import hashlib
import json
import os
from pathlib import Path
import random
import shlex
import subprocess

parser = argparse.ArgumentParser()
parser.add_argument('stage', choices=['screen', 'refine', 'confirm', 'trace'])
args = parser.parse_args()
root = Path('/home/xinze/dev/uccl-lite-blackwell-20261113')
out = root / 'build/nccl_allgather_20261115/tuning'
out.mkdir(exist_ok=True)
original = root / 'build/uccl_lite_collectives'
registered = root / 'build/nccl_allgather_20261115/ce_probe/uccl_lite_ce_probe'
lock = open('/home/xinze/dev/uccl-eat-pro6000/eval.lock', 'a')
fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
env = {k: v for k, v in os.environ.items() if not k.startswith(('NCCL_', 'UCCL_LITE_'))}
env.update(LD_LIBRARY_PATH='/opt/pytorch/cuda/lib', CUDA_VISIBLE_DEVICES='0,1', NCCL_DEBUG='WARN')
candidates = []

def add(name, settings=None, memory='plain'):
    candidates.append(dict(name=name, memory=memory, settings=settings or {}))

add('default')
for chunk in [256, 512, 2048]:
    add(f'p2p_{chunk}k', {'NCCL_P2P_PCI_CHUNKSIZE': str(chunk * 1024)})
for buffer in [1, 2, 8, 16, 32]:
    add(f'buffer_{buffer}m', {'NCCL_BUFFSIZE': str(buffer << 20)})
for chunk in [1, 2, 4]:
    add(f'p2p_{chunk}m_buffer_{8*chunk}m',
        {'NCCL_P2P_PCI_CHUNKSIZE': str(chunk << 20), 'NCCL_BUFFSIZE': str((8*chunk) << 20)})
for channels in [2, 8, 16, 32]:
    add(f'channels_{channels}', {'NCCL_MIN_NCHANNELS': str(channels), 'NCCL_MAX_NCHANNELS': str(channels)})
for threads in [128, 256]:
    add(f'threads_{threads}', {'NCCL_NTHREADS': str(threads)})
add('peer_read', {'NCCL_P2P_READ_ENABLE': '1'})
add('transport_memcpy', {'NCCL_P2P_USE_CUDA_MEMCPY': '1'})
for buffer in [8, 16, 32]:
    for channels in [8, 16]:
        add(f'buffer_{buffer}m_channels_{channels}',
            {'NCCL_BUFFSIZE': str(buffer << 20), 'NCCL_MIN_NCHANNELS': str(channels),
             'NCCL_MAX_NCHANNELS': str(channels)})
add('registered_default', memory='registered')
for buffer in [1, 16, 32]:
    add(f'registered_buffer_{buffer}m', {'NCCL_BUFFSIZE': str(buffer << 20)}, 'registered')
for channels in [8, 16]:
    add(f'registered_channels_{channels}',
        {'NCCL_MIN_NCHANNELS': str(channels), 'NCCL_MAX_NCHANNELS': str(channels)}, 'registered')
add('registered_buffer_16m_channels_16',
    {'NCCL_BUFFSIZE': str(16 << 20), 'NCCL_MIN_NCHANNELS': '16', 'NCCL_MAX_NCHANNELS': '16'}, 'registered')
add('registered_peer_read', {'NCCL_P2P_READ_ENABLE': '1'}, 'registered')
add('ce', {'NCCL_CTA_POLICY': '2'}, 'registered')
add('ce_large_chunks', {'NCCL_CTA_POLICY': '2', 'NCCL_P2P_PCI_CHUNKSIZE': str(2 << 20),
                        'NCCL_BUFFSIZE': str(16 << 20), 'NCCL_MIN_NCHANNELS': '16',
                        'NCCL_MAX_NCHANNELS': '16'}, 'registered')

if args.stage == 'refine':
    candidates = []
    add('refine_default')
    add('refine_transport_memcpy', {'NCCL_P2P_USE_CUDA_MEMCPY': '1'})
    for buffer in [1, 2, 8, 16, 32]:
        add(f'memcpy_buffer_{buffer}m',
            {'NCCL_P2P_USE_CUDA_MEMCPY': '1', 'NCCL_BUFFSIZE': str(buffer << 20)})
    for channels in [2, 8, 16]:
        add(f'memcpy_channels_{channels}',
            {'NCCL_P2P_USE_CUDA_MEMCPY': '1', 'NCCL_MIN_NCHANNELS': str(channels),
             'NCCL_MAX_NCHANNELS': str(channels)})
    for buffer in [8, 16]:
        for channels in [2, 8]:
            add(f'memcpy_buffer_{buffer}m_channels_{channels}',
                {'NCCL_P2P_USE_CUDA_MEMCPY': '1', 'NCCL_BUFFSIZE': str(buffer << 20),
                 'NCCL_MIN_NCHANNELS': str(channels), 'NCCL_MAX_NCHANNELS': str(channels)})
    add('memcpy_p2p_512k', {'NCCL_P2P_USE_CUDA_MEMCPY': '1', 'NCCL_P2P_PCI_CHUNKSIZE': str(512 << 10)})
    add('memcpy_buffer_16m_p2p_2m', {'NCCL_P2P_USE_CUDA_MEMCPY': '1', 'NCCL_BUFFSIZE': str(16 << 20),
                                   'NCCL_P2P_PCI_CHUNKSIZE': str(2 << 20)})
    add('memcpy_threads_128', {'NCCL_P2P_USE_CUDA_MEMCPY': '1', 'NCCL_NTHREADS': '128'})
    add('registered_memcpy', {'NCCL_P2P_USE_CUDA_MEMCPY': '1'}, 'registered')
    for channels in [8, 16]:
        add(f'buffer_1m_channels_{channels}', {'NCCL_BUFFSIZE': str(1 << 20),
            'NCCL_MIN_NCHANNELS': str(channels), 'NCCL_MAX_NCHANNELS': str(channels)})
    add('registered_buffer_1m_threads_128', {'NCCL_BUFFSIZE': str(1 << 20), 'NCCL_NTHREADS': '128'}, 'registered')
    (out / 'refine_candidates.json').write_text(json.dumps(candidates, indent=2) + '\n')
    random.Random(20261116).shuffle(candidates)
    jobs = [(c, 'refine_' + c['name']) for c in candidates]
elif args.stage == 'screen':
    (out / 'candidates.json').write_text(json.dumps(candidates, indent=2) + '\n')
    random.Random(20261115).shuffle(candidates)
    jobs = [(c, 'screen_' + c['name']) for c in candidates]
    jobs.insert(0, (dict(name='default', memory='plain', settings={}), 'screen_default_before'))
    jobs.append((dict(name='default', memory='plain', settings={}), 'screen_default_after'))
elif args.stage == 'confirm':
    candidates = json.loads((out / 'selected.json').read_text())
    jobs = []
    for repeat in range(3):
        ordered = candidates[repeat:] + candidates[:repeat]
        if repeat == 1:
            ordered.reverse()
        jobs += [(c, f'confirm_{c["name"]}_run{repeat+1}') for c in ordered]
else:
    candidates = json.loads((out / 'trace_selected.json').read_text())
    jobs = [(c, 'trace_' + c['name']) for c in candidates]

hashes = {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in [original, registered]}
(out / (args.stage + '_hashes.json')).write_text(json.dumps(hashes, indent=2) + '\n')
runs = []
for index, (candidate, name) in enumerate(jobs, 1):
    active = subprocess.check_output(['nvidia-smi', '--query-compute-apps=pid,process_name',
                                      '--format=csv,noheader'], text=True).strip()
    if active:
        raise RuntimeError('GPU occupied: ' + active)
    binary = registered if candidate['memory'] == 'registered' else original
    assert hashlib.sha256(binary.read_bytes()).hexdigest() == hashes[str(binary)]
    runenv = {**env, **candidate['settings']}
    if candidate['memory'] == 'registered':
        runenv['UCCL_LITE_CE_REGISTER'] = '1'
    if args.stage == 'trace':
        runenv.update(NCCL_DEBUG='TRACE', NCCL_DEBUG_SUBSYS='INIT,TUNING,COLL,ENV,P2P,SHM',
                      NCCL_DEBUG_FILE=str(out / (name + '_debug.log')))
    warmup, iterations, repeats = {'screen': (3, 3, 3), 'refine': (3, 3, 3), 'confirm': (5, 10, 5), 'trace': (1, 1, 3)}[args.stage]
    cmd = [str(binary), '--gpus', '2', '--fallback', 'nccl', '--backend', 'off',
           '--main-cpu', '23', '--op', 'allgather', '--begin', '1048576', '--end', '1073741824',
           '--warmup', str(warmup), '--iterations', str(iterations), '--repeats', str(repeats),
           '--samples', str(out / (name + '_samples.csv'))]
    started = datetime.now(timezone.utc).isoformat()
    print(f'{index}/{len(jobs)} {name}: starting', flush=True)
    with (out / (name + '.csv')).open('x') as stdout, (out / (name + '.log')).open('x') as stderr:
        process = subprocess.Popen(cmd, env=runenv, stdout=stdout, stderr=stderr)
        try:
            rc = process.wait(timeout=180)
        except subprocess.TimeoutExpired:
            process.kill()
            rc = process.wait()
    raw = (out / (name + '.csv')).read_text()
    passed = rc == 0 and '# correctness: PASS (every invocation, all ranks)' in raw
    runs.append(dict(name=name, candidate=candidate, command=shlex.join(cmd),
                     environment={k:v for k,v in runenv.items() if k.startswith(('NCCL_', 'UCCL_LITE_', 'CUDA_', 'LD_LIBRARY_PATH'))},
                     started_utc=started, finished_utc=datetime.now(timezone.utc).isoformat(),
                     returncode=rc, correctness_pass=passed))
    (out / (args.stage + '_runs.json')).write_text(json.dumps(runs, indent=2) + '\n')
    print(f'{name}: {"PASS" if passed else "FAILED (retained)"}', flush=True)
    if not passed and args.stage not in ['screen', 'refine']:
        raise RuntimeError(name)
