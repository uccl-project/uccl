include Makefile
.PHONY: nccl-ce-probe
nccl-ce-probe: build/nccl_allgather_20261115/ce_probe/uccl_lite_ce_probe
build/nccl_allgather_20261115/ce_probe/uccl_lite_ce_probe: build/nccl_allgather_20261115/ce_probe/collectives_ce_probe.cu $(LOCAL_STATIC) $(ROUTER_STATIC)
	$(NVCC) $(NVCC_FLAGS) -std=c++17 $(ROUTER_INC) -Ibenchmarks/cpu_router -I$(NCCL_HOME)/include $< $(LOCAL_STATIC) $(ROUTER_STATIC) -L$(NCCL_HOME)/lib -lnccl -Xlinker -rpath=$(NCCL_HOME)/lib -Xcompiler=-pthread -ldl -o $@
