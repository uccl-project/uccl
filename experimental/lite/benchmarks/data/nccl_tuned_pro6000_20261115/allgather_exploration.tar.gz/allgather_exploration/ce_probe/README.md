# NCCL copy-engine AllGather on aws-pro6000

On 2026-11-15, NCCL 2.29.7's copy-engine path was successfully enabled on
the two RTX PRO 6000 Blackwell Server Edition GPUs. At 1 GiB complete output
per GPU, median bus bandwidth increases from **29.13 GB/s to 35.85 GB/s**,
about 23.1%. A NCCL-managed, registered-buffer control without the CE policy
reaches **34.26 GB/s**; CE adds about 4.6% over that control. At 1 MiB CE is
slower than the original default. These are measurements of this host and
configuration, not a general NCCL policy recommendation.

## Enablement and proof

The environment knob is `NCCL_CTA_POLICY=2` (`NCCL_CTA_POLICY_ZERO`). Setting
it on the original cudaMalloc-based harness did **not** activate CE:
[`../ce_knob_debug.log`](../ce_knob_debug.log) confirms that the policy was
accepted, but every call retained RING/SIMPLE.

An isolated probe changes the input/output allocator to `ncclMemAlloc`,
registers both buffers with `ncclCommWindowRegister` and
`NCCL_WIN_COLL_SYMMETRIC` on all ranks before measurement, and deregisters
them before `ncclMemFree`. Registration is grouped across both ranks and
asserts non-null window handles. The input and output base offsets match
across ranks. Communicator setup still uses `ncclCommInitAll`; NCCL applies
the environment policy at initialization. The collector, timing intervals,
fill/check kernels, dispatch mode and actual `ncclAllGather` call are unchanged.

[`trace_debug.log`](trace_debug.log) confirms **all eleven sizes** take
`AllGather [Copy Engine]: ... Bytes -> cudaMemcpy`. There are no Ring
selection lines for those calls. NCCL's printed byte count is each rank's
contribution, half the complete-output size in the table. The separate
registered-default trace confirms RING/SIMPLE on channels 0–3.

A separate Nsight Systems trace at 1 GiB corroborates the selection:
[`ce_diagnostic_1g_cuda_gpu_kern_sum.csv`](ce_diagnostic_1g_cuda_gpu_kern_sum.csv)
contains only the fill and verification kernels, with no NCCL collective
kernel. The [memory-operation summary](ce_diagnostic_1g_cuda_gpu_mem_time_sum.csv)
records device-to-device memcpy activity. This profiling run is excluded
from the performance results.

The installed-version source gates CE on symmetric support and registered
windows: [NCCL v2.29.7 CE availability](https://github.com/NVIDIA/nccl/blob/v2.29.7-1/src/ce_coll.cc#L100).
The policy branch is in [taskAppend](https://github.com/NVIDIA/nccl/blob/v2.29.7-1/src/enqueue.cc#L2915).
No NCCL source, library, topology, driver, or clock setting was changed.

## Matched results

Hardware: two RTX PRO 6000 Blackwell Server Edition GPUs, PCIe Gen5 x16,
same switch (`PIX`), Xeon Platinum 8559C, one NUMA node. Driver 595.91.07,
CUDA runtime 13.0/compiler 13.0.88, NCCL 2.29.7+cuda13.2.
BF16, out of place, two GPUs in one process, main CPU 23, eager enqueue.

Every size is the **complete output per GPU**; contribution is half that
size. Bus bandwidth is `output_bytes / 2 / seconds / 1e9`, decimal GB/s.
The three configurations are:

- Default: original binary, cudaMalloc buffers, no registration, default CTA policy.
- Registered default: isolated binary, ncclMemAlloc and symmetric windows,
  default CTA policy. This control changes allocation **and** registration;
  their individual effects are not isolated.
- CE: identical registered probe, adding only `NCCL_CTA_POLICY=2`.

Each configuration has three separate process sweeps. Order rotates as
default/registered/CE, CE/default/registered, registered/CE/default. Each
size gets five warmups followed by five rounds of ten individually checked
calls. Each sweep reports the median of five round medians; the table uses
the median of the three sweep medians. No per-size best configuration is
selected. Timing is the slowest-rank CUDA-event interval, including eager
submission gaps; allocation, registration, communicator setup, warmups, fill
and verification are excluded. Primary timing sweeps use `NCCL_DEBUG=WARN`.

| Complete output/GPU (MiB) | Default (GB/s) | Registered default (GB/s) | CE (GB/s) |
| ---: | ---: | ---: | ---: |
| 1 | 12.59 | 12.59 | 11.60 |
| 2 | 18.07 | 19.45 | 18.49 |
| 4 | 22.70 | 25.55 | 26.63 |
| 8 | 24.57 | 29.51 | 31.62 |
| 16 | 25.38 | 31.42 | 34.04 |
| 32 | 25.98 | 32.34 | 35.00 |
| 64 | 26.41 | 32.96 | 35.52 |
| 128 | 26.73 | 33.26 | 35.66 |
| 256 | 27.25 | 34.08 | 35.78 |
| 512 | 27.94 | 34.30 | 35.83 |
| 1024 | 29.13 | 34.26 | 35.85 |

All nine primary sweeps pass full-output correctness after every invocation:
**4,950 timed calls**, plus warmups. The enablement, registered-default
selection, knob-only and profiling diagnostics also pass. The shared node
evaluation lock was held; primary runner checks GPU occupancy before and
after each process. No production router or collective implementation was
changed. The probe build and its eager calls were validated; graph mode and
other topologies/dtypes were not tested.

The branch's previously recorded UCCL peer result was 48.21 GB/s at 1 GiB,
which is still above this CE result. UCCL was not rerun in this experiment;
that comparison is across measurement windows.

## Reproduction and artifacts

[`../build_ce_probe.py`](../build_ce_probe.py) asserts the original harness
SHA-256, applies [source.patch](source.patch), and builds the variant using
the repository Makefile plus [probe.mk](probe.mk). Generated source, binaries,
dependency files, raw nsys report and SQLite database remain under the remote
`build/nccl_allgather_20261115/ce_probe/`; existing source/binaries are untouched.
[build.log](build.log) records successful sm_120 compilation.

[`../run_ce_comparison.py`](../run_ce_comparison.py) records exact commands,
environment and timestamps in [runs.json](runs.json), with binary/source/library
hashes in [hashes.json](hashes.json). The new probe uses
`UCCL_LITE_CE_REGISTER=1` to enable registration; this is a probe-only switch.
The original default has no NCCL policy override; CE sets only
`NCCL_CTA_POLICY=2` in addition to the registered control's environment.

All runs use:

```text
--gpus 2 --fallback nccl --backend off --main-cpu 23 --op allgather
--begin 1048576 --end 1073741824 --warmup 5 --iterations 10 --repeats 5
```

Run `python3 summarize.py` in this directory to reconstruct medians from all
raw samples, validate sample counts and CE selection, and regenerate
[summary.csv](summary.csv), which includes across-sweep ranges. The ranges
are descriptive, not confidence intervals. Diagnostic selection sweeps use
one warmup and three repeats of one call with INFO/TUNING logging; the nsys
run uses the same short protocol at 1 GiB only and `--trace=cuda --sample=none
--cpuctxsw=none`.
