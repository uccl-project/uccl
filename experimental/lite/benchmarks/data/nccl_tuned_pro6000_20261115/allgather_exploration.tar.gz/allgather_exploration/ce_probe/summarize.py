#!/usr/bin/env python3
"""Validate and summarize the three repeated NCCL memory/CTA configurations."""
import csv
import json
from pathlib import Path
import re
from statistics import median

root = Path(__file__).resolve().parent
modes = ['default', 'registered_default', 'ce']
measurements = {}
for mode in modes:
    measurements[mode] = {}
    for run in range(1, 4):
        name = f'{mode}_run{run}'
        raw = (root / (name + '.csv')).read_text()
        assert '# correctness: PASS (every invocation, all ranks)' in raw
        rows = list(csv.DictReader(line for line in raw.splitlines()
                                   if line.startswith(('collective,', 'all_gather,'))))
        assert len(rows) == 11
        with (root / (name + '_samples.csv')).open() as f:
            samples = list(csv.DictReader(f))
        assert len(samples) == 550
        for row in rows:
            assert row['in_place'] == '0' and row['dispatcher_router_initialized'] == '0'
            size = int(row['bytes'])
            repeats = []
            for repeat in range(5):
                group = [float(s['slowest_rank_us']) for s in samples
                         if int(s['bytes']) == size and int(s['repeat']) == repeat]
                assert len(group) == 10
                repeats.append(median(group))
            result = median(repeats)
            assert abs(result - float(row['median_us'])) < 0.001
            measurements[mode].setdefault(size, []).append(result)

trace = (root / 'trace_debug.log').read_text()
ce_sizes = set(int(value) for value in re.findall(r'AllGather \[Copy Engine\]: (\d+) Bytes', trace))
assert ce_sizes == {2**i for i in range(19, 30)}
assert not re.search(r'AllGather: .*Bytes -> Algo', trace)
assert all(run['returncode'] == 0 for run in json.loads((root / 'runs.json').read_text()))

fields = ['output_bytes_per_gpu', 'input_bytes_per_gpu']
for mode in modes:
    fields += [f'{mode}_us', f'{mode}_bus_GB_s', f'{mode}_min_bus_GB_s', f'{mode}_max_bus_GB_s']
fields += ['ce_speedup_vs_default', 'ce_speedup_vs_registered_default']
with (root / 'summary.csv').open('w') as f:
    writer = csv.DictWriter(f, fieldnames=fields)
    writer.writeheader()
    for size in sorted(measurements['default']):
        result = dict(output_bytes_per_gpu=size, input_bytes_per_gpu=size // 2)
        central = {}
        for mode in modes:
            times = measurements[mode][size]
            central[mode] = median(times)
            bandwidth = lambda us: size / 2 / us / 1000
            result.update({f'{mode}_us': central[mode],
                           f'{mode}_bus_GB_s': bandwidth(central[mode]),
                           f'{mode}_min_bus_GB_s': bandwidth(max(times)),
                           f'{mode}_max_bus_GB_s': bandwidth(min(times))})
        result['ce_speedup_vs_default'] = central['default'] / central['ce']
        result['ce_speedup_vs_registered_default'] = central['registered_default'] / central['ce']
        writer.writerow(result)
        values = [result[f'{mode}_bus_GB_s'] for mode in modes]
        print(f'| {size // 1048576} | {values[0]:.2f} | {values[1]:.2f} | {values[2]:.2f} |')
