#!/usr/bin/env python3
"""Summarize independent NCCL sweeps; preserve initialization log prefixes."""
import csv
from pathlib import Path
import statistics

root = Path(__file__).resolve().parent
runs = []
for name in ['run1', 'run2', 'run3']:
    text = (root / f'{name}.csv').read_text()
    assert '# correctness: PASS (every invocation, all ranks)' in text
    rows = list(csv.DictReader(line for line in text.splitlines()
                               if line.startswith(('collective,', 'all_gather,'))))
    assert len(rows) == 11
    assert all(row['backend'] == 'fallback' and row['dispatcher_router_initialized'] == '0' for row in rows)
    samples = list(csv.DictReader((root / f'{name}_samples.csv').open()))
    assert len(samples) == 550
    runs.append({int(row['bytes']): row for row in rows})
edges = (root / 'transport_edges.txt').read_text().splitlines()
assert len(edges) == 8 and all('via P2P/direct pointer' in edge for edge in edges)
assert any('0[0] -> 1[1]' in edge for edge in edges)
assert any('1[1] -> 0[0]' in edge for edge in edges)
with (root / 'summary.csv').open('w') as output:
    writer = csv.writer(output)
    writer.writerow(['output_bytes_per_gpu', 'input_bytes_per_gpu', 'median_us', 'bus_GB_s',
                     'run_min_bus_GB_s', 'run_max_bus_GB_s', 'run1_us', 'run2_us', 'run3_us'])
    for size in sorted(runs[0]):
        times = [float(run[size]['median_us']) for run in runs]
        median = statistics.median(times)
        bandwidth = lambda us: size * 0.5 / us / 1000
        low, high = min(map(bandwidth, times)), max(map(bandwidth, times))
        writer.writerow([size, size // 2, f'{median:.3f}', f'{bandwidth(median):.4f}',
                         f'{low:.4f}', f'{high:.4f}', *times])
        print(f'| {size // 1048576} | {bandwidth(median):.2f} | {low:.2f}–{high:.2f} |')
