#!/usr/bin/env python3
"""Rotate default, symmetric-default, and symmetric-copy-engine NCCL controls."""
import fcntl
import hashlib
import json
import os
from pathlib import Path
import shlex
import subprocess
from datetime import datetime, timezone

root = Path('/home/xinze/dev/uccl-lite-blackwell-20261113')
out = root / 'build/nccl_allgather_20261115/ce_probe'
original = root / 'build/uccl_lite_collectives'
variant = out / 'uccl_lite_ce_probe'
lock = open('/home/xinze/dev/uccl-eat-pro6000/eval.lock', 'a')
fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
env = {k: v for k, v in os.environ.items() if not k.startswith(('NCCL_', 'UCCL_LITE_'))}
env.update(LD_LIBRARY_PATH='/opt/pytorch/cuda/lib', CUDA_VISIBLE_DEVICES='0,1', NCCL_DEBUG='WARN')
modes = {
    'default': (original, {}),
    'registered_default': (variant, dict(UCCL_LITE_CE_REGISTER='1')),
    'ce': (variant, dict(UCCL_LITE_CE_REGISTER='1', NCCL_CTA_POLICY='2')),
}
runs = []
hashes = {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in [original, variant,
    out / 'collectives_ce_probe.cu', root / 'build/libuccl_lite_local_collectives.a',
    root / 'build/cpu_router/libuccl_lite_cpu_router.a',
    Path('/home/xinze/dev/uccl-lite-test-20261113/build/testbed/deps/nccl/lib/libnccl.so.2')]}
(out / 'hashes.json').write_text(json.dumps(hashes, indent=2) + '\n')

def idle():
    processes = subprocess.check_output(['nvidia-smi', '--query-compute-apps=pid,process_name',
                                         '--format=csv,noheader'], text=True).strip()
    if processes:
        raise RuntimeError('GPU occupied: ' + processes)

for repeat, order in enumerate([['default', 'registered_default', 'ce'],
                                ['ce', 'default', 'registered_default'],
                                ['registered_default', 'ce', 'default']], 1):
    for mode in order:
        idle()
        binary, extra = modes[mode]
        assert hashlib.sha256(binary.read_bytes()).hexdigest() == hashes[str(binary)]
        name = f'{mode}_run{repeat}'
        cmd = [str(binary), '--gpus', '2', '--fallback', 'nccl', '--backend', 'off',
               '--main-cpu', '23', '--op', 'allgather', '--begin', '1048576',
               '--end', '1073741824', '--warmup', '5', '--iterations', '10',
               '--repeats', '5', '--samples', str(out / (name + '_samples.csv'))]
        runenv = {**env, **extra}
        started = datetime.now(timezone.utc).isoformat()
        print(name + ': starting', flush=True)
        with (out / (name + '.csv')).open('x') as stdout, (out / (name + '.log')).open('x') as stderr:
            result = subprocess.run(cmd, env=runenv, stdout=stdout, stderr=stderr, timeout=300)
        runs.append(dict(name=name, command=shlex.join(cmd), started_utc=started,
                         finished_utc=datetime.now(timezone.utc).isoformat(),
                         environment={k: v for k, v in runenv.items()
                                      if k.startswith(('NCCL_', 'UCCL_LITE_', 'CUDA_', 'LD_LIBRARY_PATH'))},
                         returncode=result.returncode))
        (out / 'runs.json').write_text(json.dumps(runs, indent=2) + '\n')
        assert result.returncode == 0, name
        assert '# correctness: PASS (every invocation, all ranks)' in (out / (name + '.csv')).read_text(), name
        idle()
        print(name + ': correctness PASS', flush=True)
