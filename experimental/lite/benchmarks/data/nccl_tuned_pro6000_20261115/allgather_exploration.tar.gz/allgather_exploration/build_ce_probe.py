#!/usr/bin/env python3
"""Build an isolated symmetric-memory variant of the recorded NCCL harness."""
import difflib
import hashlib
from pathlib import Path
import subprocess

root = Path('/home/xinze/dev/uccl-lite-blackwell-20261113')
out = root / 'build/nccl_allgather_20261115/ce_probe'
out.mkdir(exist_ok=True)
source = root / 'benchmarks/cpu_router/collectives_bench.cu'
original = source.read_text()
assert hashlib.sha256(source.read_bytes()).hexdigest() == '3e545428cd30f6fdbb349f8118838c8ba09ae4bcfe44daf0f8429ade38d7cc50'
modified = original

def replace(before, after):
    global modified
    assert modified.count(before) == 1, before
    modified = modified.replace(before, after)

replace('  std::vector<int> devices;\n  Buffers(std::vector<int> const& ids, size_t bytes) : devices(ids) {', '''  std::vector<int> devices;
  std::vector<ncclComm_t> comms;
  std::vector<ncclWindow_t> inputWindows, outputWindows;
  bool registered = std::getenv("UCCL_LITE_CE_REGISTER") != nullptr;
  Buffers(std::vector<int> const& ids, size_t bytes,
          std::vector<ncclComm_t> const& communicators)
      : devices(ids), comms(communicators) {''')
replace('      cudaCheck(cudaMalloc(&in, bytes));\n      cudaCheck(cudaMalloc(&out, bytes));',
        '      ncclCheck(ncclMemAlloc(&in, bytes));\n      ncclCheck(ncclMemAlloc(&out, bytes));')
replace('      stop.push_back(b);\n    }\n  }\n  ~Buffers() {', '''      stop.push_back(b);
    }
    if (registered) {
      if (comms.size() != devices.size())
        throw std::runtime_error("CE probe requires NCCL communicators");
      inputWindows.resize(devices.size());
      outputWindows.resize(devices.size());
      ncclCheck(ncclGroupStart());
      for (size_t r = 0; r < devices.size(); ++r) {
        cudaCheck(cudaSetDevice(devices[r]));
        ncclCheck(ncclCommWindowRegister(comms[r], inputs[r], bytes,
                                        &inputWindows[r],
                                        NCCL_WIN_COLL_SYMMETRIC));
        ncclCheck(ncclCommWindowRegister(comms[r], outputs[r], bytes,
                                        &outputWindows[r],
                                        NCCL_WIN_COLL_SYMMETRIC));
      }
      ncclCheck(ncclGroupEnd());
      for (size_t r = 0; r < devices.size(); ++r)
        if (!inputWindows[r] || !outputWindows[r])
          throw std::runtime_error("symmetric window registration unavailable");
      std::fprintf(stderr, "# symmetric input/output windows registered on all ranks\\n");
    }
  }
  ~Buffers() {''')
replace('      cudaFree(inputs[r]);\n      cudaFree(outputs[r]);', '''      if (registered) {
        ncclCommWindowDeregister(comms[r], inputWindows[r]);
        ncclCommWindowDeregister(comms[r], outputWindows[r]);
      }
      ncclMemFree(inputs[r]);
      ncclMemFree(outputs[r]);''')
replace('      Buffers buffers(cfg.devices, cfg.end);',
        '      Buffers buffers(cfg.devices, cfg.end, comms);')
(out / 'collectives_ce_probe.cu').write_text(modified)
(out / 'source.patch').write_text(''.join(difflib.unified_diff(
    original.splitlines(True), modified.splitlines(True),
    fromfile='benchmarks/cpu_router/collectives_bench.cu', tofile='build/ce_probe/collectives_ce_probe.cu')))
makefile = '''include Makefile
.PHONY: nccl-ce-probe
nccl-ce-probe: build/nccl_allgather_20261115/ce_probe/uccl_lite_ce_probe
build/nccl_allgather_20261115/ce_probe/uccl_lite_ce_probe: build/nccl_allgather_20261115/ce_probe/collectives_ce_probe.cu $(LOCAL_STATIC) $(ROUTER_STATIC)
\t$(NVCC) $(NVCC_FLAGS) -std=c++17 $(ROUTER_INC) -Ibenchmarks/cpu_router -I$(NCCL_HOME)/include $< $(LOCAL_STATIC) $(ROUTER_STATIC) -L$(NCCL_HOME)/lib -lnccl -Xlinker -rpath=$(NCCL_HOME)/lib -Xcompiler=-pthread -ldl -o $@
'''
(out / 'probe.mk').write_text(makefile)
cmd = ['bash', 'build/blackwell/build.sh', '-f', str(out / 'probe.mk'), 'nccl-ce-probe']
with (out / 'build.log').open('w') as log:
    subprocess.run(cmd, cwd=root, stdout=log, stderr=subprocess.STDOUT, check=True)
print('CE probe build PASS', flush=True)
