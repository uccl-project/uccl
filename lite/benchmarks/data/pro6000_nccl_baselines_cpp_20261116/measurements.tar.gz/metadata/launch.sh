#!/usr/bin/env bash
set -euo pipefail
cd /home/wxzheng/uccl-lite-nccl-baselines-20261116
source /home/wxzheng/eat-pcieccl-vllm-pro6000-20261115-074910/runtime_env.sh
export LD_LIBRARY_PATH="$CUDA_HOME/lib:$CUDA_HOME/lib64"
python3 -B scripts/run_pro6000_nccl_baselines.py run --output build/epoch-v1 --ar-policy benchmarks/data/pro6000_allreduce_ce_ring_cpp_20261116/frozen-policy.json --ag-rs-policy benchmarks/data/pro6000_ag_rs_cpp_20261116/policy.json
