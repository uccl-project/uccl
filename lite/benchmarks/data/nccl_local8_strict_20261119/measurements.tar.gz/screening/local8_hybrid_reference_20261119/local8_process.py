"""Guard local GPU measurements; terminate only the measurement's process tree."""
import os
from pathlib import Path
import signal
import subprocess
import time


def gpu_users():
    text = subprocess.check_output(['nvidia-smi', '--query-compute-apps=pid',
                                    '--format=csv,noheader,nounits'], text=True)
    return {int(x) for x in text.split()}


def descendant(pid, root):
    seen = set()
    while pid > 1 and pid not in seen:
        if pid == root:
            return True
        seen.add(pid)
        try:
            status = Path(f'/proc/{pid}/status').read_text()
        except FileNotFoundError:
            return True  # Exited between the GPU and process snapshots.
        pid = int(next(line.split()[1] for line in status.splitlines()
                       if line.startswith('PPid:')))
    return False


def process_tree(root):
    # Track launchers before their CUDA contexts appear. During MPI error
    # teardown a rank can be reparented before NVML reports its final context.
    rows = subprocess.check_output(['ps', '-eo', 'pid=,ppid='], text=True)
    parents = {int(pid): int(parent) for pid, parent in
               (line.split() for line in rows.splitlines())}
    result = {root}
    while True:
        children = {pid for pid, parent in parents.items() if parent in result}
        if children <= result:
            return result
        result.update(children)


def wait(child, timeout):
    start = time.monotonic()
    owned = set()
    try:
        while child.poll() is None:
            owned.update(process_tree(child.pid))
            users = gpu_users()
            foreign = {pid for pid in users if pid not in owned and not descendant(pid, child.pid)}
            if foreign:
                raise RuntimeError(f'foreign GPU work during measurement: {sorted(foreign)}')
            owned.update(users)
            if time.monotonic() - start > timeout:
                raise TimeoutError('measurement timeout')
            try:
                child.wait(timeout=1)
            except subprocess.TimeoutExpired:
                pass
        # Open MPI can return immediately after signaling failed ranks. Their
        # CUDA contexts may take a moment to disappear from NVML. Wait only
        # for ranks observed as our descendants, never for unrelated GPU work.
        deadline = time.monotonic() + 10
        while users := gpu_users():
            if users - owned or time.monotonic() >= deadline:
                raise RuntimeError('GPU processes remain after measurement')
            time.sleep(.2)
        return child.returncode
    except BaseException:
        if child.poll() is None:
            os.killpg(child.pid, signal.SIGTERM)
            try:
                child.wait(timeout=10)
            except subprocess.TimeoutExpired:
                os.killpg(child.pid, signal.SIGKILL)
                child.wait()
        raise
