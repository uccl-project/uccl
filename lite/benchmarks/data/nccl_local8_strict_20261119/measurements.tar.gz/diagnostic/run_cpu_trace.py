import sys,json,subprocess,fcntl
from pathlib import Path
root=Path.cwd();sys.path.insert(0,str(root/'tests/nccl_mscclpp'))
import local8_process
source=root/'build/local8_cpu_trace_profile_20261119';out=root/'build/local8_diagnostic_20261119'
m=json.loads((source/'manifest.json').read_text());env=m['environment']
lock=open('/tmp/uccl-lite-integration-wxz-l4.lock','a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
if local8_process.gpu_users():raise RuntimeError('GPU occupied')
cmd=['mpirun','--timeout','180','-np','8','--bind-to','none','--map-by','slot','--mca','pml','ob1','--mca','btl','self,vader,tcp',
     'python3','-B',str(source/'mscclpp_profile.py'),'launch','--local8','--library',str(source/'libuccl_lite_nccl_trace.so'),
     '--real-nccl',str(root/'build/nccl-2.28.9/lib/libnccl.so.2'),'--profile',str(source/'candidate.tsv'),'--',
     str(root/'build/nccl_local8/reference_timing_check'),'ar','out','1024','2097152','5','10','3']
(out/'cpu_command.json').write_text(json.dumps({'argv':cmd,'scope':'instrumented diagnostic only'},indent=2)+'\n')
with (out/'cpu_trace.log').open('x') as log:
 child=subprocess.Popen(cmd,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 status=local8_process.wait(child,200)
print('CPU trace status',status,flush=True)
