import sys,os,json,subprocess,fcntl
from pathlib import Path
root=Path.cwd();sys.path.insert(0,str(root/'tests/nccl_mscclpp'))
import local8_process
out=root/'build/local8_diagnostic_20261119'
source=root/'build/local8_spin32_screen_20261119'
manifest=json.loads((source/'manifest.json').read_text());env=manifest['environment']
lock=open('/tmp/uccl-lite-integration-wxz-l4.lock','a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
if local8_process.gpu_users():raise RuntimeError('GPU occupied')
cmd=['mpirun','--timeout','240','-np','8','--bind-to','none','--map-by','slot','--mca','pml','ob1','--mca','btl','self,vader,tcp',
     'python3','-B',str(source/'mscclpp_profile.py'),'launch','--local8','--library',str(source/'libuccl_lite_nccl_local8.so'),
     '--real-nccl',str(root/'build/nccl-2.28.9/lib/libnccl.so.2'),'--profile',str(source/'candidate.tsv'),'--',
     '/opt/nvidia/nsight-systems/2025.3.2/bin/nsys','profile','--trace=cuda,osrt','--sample=none','--cpuctxsw=none',
     '--force-overwrite=false','-o',str(out/'trace_%p'),str(root/'build/nccl_local8/reference_timing_check'),'ar','out','1024','2097152','5','10','3']
(out/'command.json').write_text(json.dumps({'argv':cmd,'scope':'instrumented diagnostic only; not performance admission'},indent=2)+'\n')
with (out/'trace.log').open('x') as log:
 child=subprocess.Popen(cmd,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 status=local8_process.wait(child,270)
print('trace status',status,flush=True)
