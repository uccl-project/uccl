// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.

#ifndef MSCCLPP_VERSION_HPP_
#define MSCCLPP_VERSION_HPP_

#define MSCCLPP_MAJOR 0
#define MSCCLPP_MINOR 9
#define MSCCLPP_PATCH 0
#define MSCCLPP_VERSION (MSCCLPP_MAJOR * 10000 + MSCCLPP_MINOR * 100 + MSCCLPP_PATCH)
#define MSCCLPP_GIT_COMMIT "6231b4f38ddc"

#endif  // MSCCLPP_VERSION_HPP_
